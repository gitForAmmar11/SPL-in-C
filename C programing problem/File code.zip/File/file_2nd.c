#include<stdio.h>

int main(){
    FILE *fptr;
    char pdf[100];

    // fptr = fopen("a.pdf", "rb");

    // read file using strings
    // while (fgets(pdf, sizeof(pdf), fptr))
    // {
    //     printf("%s", pdf);
    // }
    
    // read entire file using ch
    char ch;
    // while (fscanf(fptr, "%c", &ch) != EOF)
    // {
    //     printf("%c", ch);
    // }
    
    // printf("%s", pdf);

    // fclose(fptr);

    // wb
    // fptr = fopen("a.pdf", "wb");
    // int count = 0;

    // fseek(fptr, 100, SEEK_SET);
    // fprintf(fptr, "%c", 'a');

    // fclose(fptr);

    // replace occurences of a certain character

    fptr = fopen("a.txt", "r+");

    while (!feof(fptr))
    {
        fscanf(fptr, "%c", &ch);
        // printf("%c", ch);
        if(ch == 'n'){
            fseek(fptr, -1, SEEK_CUR);
            fprintf(fptr, "%c", 'a');
        }
    }
    
    fclose(fptr);
    return 0;

}