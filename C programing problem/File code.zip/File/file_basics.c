#include<stdio.h>
#include<stdlib.h>

int main(){
    FILE* fptr;
    char name[30];

    // read
    // fptr = fopen("b.txt", "r");

    // if(!fptr){
    //     exit(1);
    // }

    // fscanf(fptr, "%s", name);
    // printf("%s\n", name);
    // // fprintf(fptr, "%s", "Limon");

    // fclose(fptr);

    // writing
    // fptr = fopen("a.txt", "w");
    // fprintf(fptr, "%s", "Redwan");

    // fclose(fptr);

    // fptr = fopen("c.txt", "w");
    // fprintf(fptr, "%s", "Abdullah");

    // fclose(fptr);

    // append
    // fptr = fopen("c.txt", "a");
    // fprintf(fptr, "%s", "Abdullah");

    // fclose(fptr);

    // fseek

    // fptr = fopen("a.txt", "r");

    // fseek(fptr, 7, SEEK_CUR);
    // fseek(fptr, 3, SEEK_CUR);
    // fscanf(fptr, "%s", name);
    // printf("%s\n", name);

    // rewind(fptr);
    // fscanf(fptr, "%s", name);
    // printf("%s\n", name);

    // fclose(fptr);

    // fgets
    // fptr = fopen("b.txt", "r");

    // fgets(name, 50, fptr);
    // puts(name);

    // fclose(fptr);

    // fputs
    // fptr = fopen("b.txt", "w");
    // fputs("Kona is always late", fptr);

    // fclose(fptr);

    // reading int
    int t = 0;
    // fptr = fopen("int.txt", "r");

    // if(!fptr){
    //     exit(1);
    // }

    // fscanf(fptr, "%d", &t);
    // printf("%d\n", t);

    // read and print all names
    char c;
    fptr = fopen("a.txt", "r");

    while (fscanf(fptr, "%c", &c) != EOF)
    {
        if (c == '\n'){
            name[t++] = '\0';
            printf("%s\n", name);
            t = 0;
            continue;
        }
        name[t++] = c;
    }

    name[t++] = '\0';
    printf("%s\n", name);
    
    fclose(fptr);

    return 0;
}