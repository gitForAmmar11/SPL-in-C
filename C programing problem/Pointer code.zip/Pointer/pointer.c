#include<stdio.h>

int main(){
    int *ad, c;
    c = 5;
    // assigning the address
    ad = &c;

    // dereferencing the address
    printf("%d %d\n", ad, *ad);

    // do not do this
    // ad = 00000001;
    // printf("%d %d\n", ad, *ad);

    c = 1;
    printf("%d %d\n", ad, *ad);

    int d = -10;
    ad = &d;
    printf("%d %d\n", ad, *ad);

    printf("%d\n", d);
    *ad = 100;
    printf("%d\n", d);

    return 0;
}