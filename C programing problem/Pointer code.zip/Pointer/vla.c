#include<stdio.h>
#include<stdarg.h>

float average(int size, ...){
    va_list v_length_list;

    int sum = 0;

    va_start(v_length_list, size);

    for(int i=0; i<size; i++){
        
        sum += va_arg(v_length_list, int);
    }

    va_end(v_length_list);

    return sum * 1.0 / size;

}

int main(){
    float avg = average(3, 3, 4, 5);
    printf("%f\n", avg);
    return 0;
}