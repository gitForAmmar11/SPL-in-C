#include<stdio.h>
#include<stdlib.h>

int main(){
    int *ptr, size, i;
    scanf("%d", &size);

    // malloc demo
    ptr = (int*) malloc(size * sizeof(int));

    for(i=0; i<size; i++){
        scanf("%d", ptr+i);
    }

    for(i=0; i<size; i++){
        printf("%d ", *(ptr+i));
    }

    // calloc demo

    // ptr = (int*) calloc(size, sizeof(int));

    // for(i=0; i<size; i++){
    //     scanf("%d", ptr+i);
    // }

    // for(i=0; i<size; i++){
    //     printf("%d ", *(ptr+i));
    // }

    // realloc demo
    int new_size = 5;

    ptr = realloc(ptr, new_size * sizeof(int));

    printf("\n");
    for(i=0; i<new_size; i++){
        scanf("%d", ptr+i);
    }

    for(i=0; i<new_size; i++){
        printf("%d ", *(ptr+i));
    }

    // free demo

    free(ptr);

    printf("\n");
    
    for(i=0; i<size; i++){
        printf("%d ", *(ptr+i));
    }

    printf("\n");

    return 0;
}