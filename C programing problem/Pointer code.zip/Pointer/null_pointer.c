#include<stdio.h>

int main()
{
    // null pointer
    int *ptr = NULL , *ptr2, b;
    // ptr2 = &b;
    // printf("%d", *ptr);

    // detecting a null pointer
    if(ptr){
        printf("not null\n");
    }
    else {
        printf("null\n");
    }

    if(ptr2){
        printf("not null\n");
    }
    else {
        printf("null\n");
    }

    // assigning address to null pointer
    int a;
    a = 10;
    ptr = &a;
    printf("%d", *ptr);

    return 0;
}
