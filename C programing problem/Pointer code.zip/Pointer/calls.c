#include<stdio.h>

typedef struct prdct
{
    int price;
    int quantity;
} product;


// call by value
int modify(int a){
    a += 10;
    printf("%d\n", a);
    return a;
}

// call by reference
void actual_modify(int *p){
    *p += 20;
}

// array
void arr_mod(int arr[], int n){
    for(int i=0; i<n; i++){
        arr[i] += 20;
    }
}

// struct and union pointers
product update_product_cbv(product prd){
    prd.price += 10;
    prd.quantity += 10;
    return prd;
}

product update_product_cbr(product *prd){
    prd->price += 10;
    prd->quantity += 10;
    return *prd;
}


int main(){
    // int b = 50;
    // int c = modify(b);
    // actual_modify(&b);
    // printf("%d %d\n",b, c);

    // passing array to function
    // int arr[5] = {0};
    // for(int i=0; i<5; i++){
    //     printf("%d ", *(arr+i));
    // }
    // printf("\n");
    // arr_mod(arr, 5);

    // for(int i=0; i<5; i++){
    //     printf("%d ", arr[i]);
    // }
    // printf("\n");

    product p1, p2;

    p1.price = 10;
    p1.quantity = 20;
    
    p2 = update_product_cbr(&p1);

    printf("%d %d\n", p1.price, p2.price);

    return 0;
}