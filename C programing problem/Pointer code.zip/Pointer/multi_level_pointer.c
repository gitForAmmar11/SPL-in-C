#include<stdio.h>

int main(){
    int **ptr, a;
    a = 100;
    printf("Address of a = %d\n", &a);

    *ptr = &a;
    printf("%d\n", *ptr);

    printf("%d\n", **ptr);

    a = 0x100;
    printf("%d\n", **ptr);
    return 0;
}