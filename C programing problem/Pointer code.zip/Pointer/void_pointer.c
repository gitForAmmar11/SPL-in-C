#include<stdio.h>
#include<stdlib.h>

int main(){
    void *p;
    int i = 10;

    p = &i;

    printf("%d\n", *(int *)p);

    return 0;
}