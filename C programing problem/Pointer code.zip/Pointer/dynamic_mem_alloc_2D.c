#include<stdio.h>
#include<stdlib.h>

int main(){

    // using single pointer
    int *ptr, row = 3, column = 2;

    // ptr = (int *) malloc(row * column * sizeof(int));

    // for(int i=0; i<row; i++){
    //     for(int j=0; j<column; j++){
    //         scanf("%d", ptr + i * column + j);
    //     }
    // }

    // for(int i=0; i<row; i++){
    //     for(int j=0; j<column; j++){
    //         printf("%d ", *(ptr + i * column + j));
    //     }
    //     printf("\n");
    // }

    // using array of pointers
    // int *ptr1[row];

    // for(int i=0; i<row; i++){
    //     ptr1[i] = (int *) malloc(column * sizeof(int));
    // }

    // for(int i=0; i<row; i++){
    //     for(int j=0; j<column; j++){
    //         scanf("%d", ptr1[i] + j);
    //     }
    // }

    // for(int i=0; i<row; i++){
    //     for(int j=0; j<column; j++){
    //         printf("%d ", *(ptr1[i] + j));
    //     }
    //     printf("\n");
    // }

    // using multilevel pointer

    int **mt = (int **) malloc(row * sizeof(int *));
    for(int i=0; i<row; i++){
        mt[i] = (int *) malloc(column * sizeof(int));
    }

    int count = 0;

    for (int i = 0; i < row; i++){
        for (int j = 0; j < column; j++)
        {
            mt[i][j] = ++count;
        }      
    }
    
    for(int i=0; i<row; i++){
        for(int j=0; j<column; j++){
            printf("%d ", mt[i][j]);
        }
        printf("\n");
    }


    return 0;
}